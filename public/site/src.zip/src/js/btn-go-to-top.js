function initBtnGoToTop() {
    const btnGoToTop = document.querySelector('#btn-go-to-top');
    const btnGoToTopCircle = document.querySelector('#btn-go-to-top svg .outer_circle');
    const scrollOffset = 200

    if (btnGoToTop) {
        window.addEventListener("scroll", function () {
            if (document.body.scrollTop > scrollOffset // For Safari
                || document.documentElement.scrollTop > scrollOffset // For Chrome, Firefox, IE and Opera
            ) {
                btnGoToTop.classList.add('show');
            } else {
                btnGoToTop.classList.remove('show');
            }

            const scrollPercent = getScrollPercent(scrollOffset)
            console.log(scrollPercent)

            btnGoToTopCircle.style.strokeDashoffset =
                410 // minimum stroke-dashoffset (no stroke)
                - (scrollPercent * 410 / 100)
        })
    }
}

window.addEventListener("DOMContentLoaded", function () {
    initBtnGoToTop()
})
