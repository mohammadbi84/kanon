function initTopSlider() {
    // init slider
    const slider = tns({
        container: ".top-slider",
        items: 1,
        slideBy: "page",
        loop: true,
        controls: false,
        mouseDrag: true,
        autoplay: false, // غیرفعال‌کردن اتوپلی داخلی
        speed: 500,
        autoplayButtonOutput: false,
        nav: false,
        onInit: (e) => {
            // dispatchEvent(new CustomEvent('indexChanged', { detail: { info: slider.getInfo() } }))
        },
    });

    // تعریف عناصر
    const thumbsList = document.querySelector(".top-slider-thumbs");
    const thumbs = thumbsList.querySelectorAll(".item");
    const slides = document.querySelectorAll(".top-slider .item");
    const videos = document.querySelectorAll(".top-slider video");
    const textContainers = document.querySelectorAll(".top-slider .item .text-container");

    let timeoutId = null;
    let isVideoPlaying = false;

    // هندلر تعویض اسلاید
    const sliderIndexChangeHandler = function (info, eventName) {
        const indexPrev = info.indexCached - 1,
              indexCurrent = info.displayIndex - 1;

        document.getElementById("shomare").innerHTML = info.displayIndex;

        if (
            indexCurrent > info.slideCount - 1 ||
            indexCurrent < 0
        ) return;

        thumbs[indexPrev]?.classList.remove("active");
        thumbs[indexCurrent]?.classList.add("active");

        centerInParent(
            thumbs[indexCurrent].parentElement,
            thumbs[indexCurrent]
        );

        clearTimeout(timeoutId);
        playNextSlide(); // اجرای تایمر بعدی
    };

    slider.events.on("indexChanged", sliderIndexChangeHandler);

    // ناوبری دستی
    document.querySelector(".nav-btn.prev").addEventListener("click", () => {
        slider.goTo("prev");
    });
    document.querySelector(".nav-btn.next").addEventListener("click", () => {
        slider.goTo("next");
    });

    // توقف/اجرای اسلایدر با موس روی اسلایدر
    document.querySelector(".top-slider").addEventListener("mousedown", () => {
        slider.pause();
        clearTimeout(timeoutId);
    });
    document.querySelector(".top-slider").addEventListener("mouseup", () => {
        slider.play();
        playNextSlide();
    });

    // ناوبری با کلیک روی تصاویر کوچک
    thumbs.forEach((el) => {
        el.addEventListener("click", () => {
            slider.goTo(el.dataset.index);
        });
    });

    thumbsList.addEventListener("mouseover", () => {
        slider.pause();
        clearTimeout(timeoutId);
    });
    thumbsList.addEventListener("mouseout", () => {
        slider.play();
        playNextSlide();
    });

    // تنظیم موقعیت متن‌ها
    const thumbsListBounds = thumbsList.getBoundingClientRect();
    const thumbsListContainerBounds = thumbsList.parentElement.getBoundingClientRect();

    for (const textContainer of textContainers) {
        textContainer.addEventListener("mouseover", () => {
            slider.pause();
            clearTimeout(timeoutId);
        });
        textContainer.addEventListener("mouseout", () => {
            slider.play();
            playNextSlide();
        });

        textContainer.style.bottom = thumbsListContainerBounds.bottom - thumbsListBounds.bottom + "px";
        textContainer.style.right = thumbsListBounds.left + "px";
    }

    // مدیریت پخش اسلاید بعدی با زمان اختصاصی
    const playNextSlide = () => {
        if (isVideoPlaying) return;

        const info = slider.getInfo();
        const currentSlide = slides[info.index % slides.length];
        const duration = parseInt(currentSlide.dataset.duration) || 3000;

        timeoutId = setTimeout(() => {
            slider.goTo("next");
        }, duration);
    };

    // مدیریت پخش ویدیو
    videos.forEach((video) => {
        video.addEventListener("play", () => {
            isVideoPlaying = true;
            clearTimeout(timeoutId);
            slider.pause();
        });
        video.addEventListener("pause", () => {
            isVideoPlaying = false;
            slider.play();
            playNextSlide();
        });
        video.addEventListener("ended", () => {
            isVideoPlaying = false;
            slider.play();
            playNextSlide();
        });
    });

    // اجرای هندلر اسلاید اول
    sliderIndexChangeHandler(slider.getInfo(), "indexChanged");

    return slider;
}


