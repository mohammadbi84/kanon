function initBtnSupport() {
    const btnSupport = document.querySelector('#btn-support');
    const scrollOffset = 200

    if (btnSupport) {
        window.addEventListener("scroll", function () {
            if (document.body.scrollTop > scrollOffset // For Safari
                || document.documentElement.scrollTop > scrollOffset // For Chrome, Firefox, IE and Opera
            ) {
                btnSupport.classList.add('show');
            } else {
                btnSupport.classList.remove('show');
            }
        })
    }
}

window.addEventListener("DOMContentLoaded", function () {
    initBtnSupport()
})
