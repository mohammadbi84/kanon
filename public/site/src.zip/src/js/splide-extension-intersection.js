/*!
 * @splidejs/splide-extension-intersection
 * Version  : 0.2.0
 * License  : MIT
 * Copyright: 2022 Naotoshi Fujita
 */ (function (b) {
    typeof define == "function" && define.amd ? define(b) : b();
})(function () {
    "use strict";
    function b(n) {
        n.length = 0;
    }
    function y(n, e, i) {
        return Array.prototype.slice.call(n, e, i);
    }
    function E(n) {
        return n.bind.apply(n, [null].concat(y(arguments, 1)));
    }
    function w(n, e) {
        return typeof e === n;
    }
    var _ = Array.isArray;
    E(w, "function"), E(w, "string"), E(w, "undefined");
    function O(n) {
        return _(n) ? n : [n];
    }
    function T(n, e) {
        O(n).forEach(e);
    }
    var V = Object.keys;
    function N(n, e, i) {
        if (n) {
            var t = V(n);
            t = i ? t.reverse() : t;
            for (var f = 0; f < t.length; f++) {
                var o = t[f];
                if (o !== "__proto__" && e(n[o], o) === !1) break;
            }
        }
        return n;
    }
    function C(n) {
        return (
            y(arguments, 1).forEach(function (e) {
                N(e, function (i, t) {
                    n[t] = e[t];
                });
            }),
            n
        );
    }
    function g() {
        var n = [];
        function e(c, r, s, a) {
            f(c, r, function (u, l, d) {
                var m = "addEventListener" in u,
                    v = m
                        ? u.removeEventListener.bind(u, l, s, a)
                        : u.removeListener.bind(u, s);
                m ? u.addEventListener(l, s, a) : u.addListener(s),
                    n.push([u, l, d, s, v]);
            });
        }
        function i(c, r, s) {
            f(c, r, function (a, u, l) {
                n = n.filter(function (d) {
                    return d[0] === a &&
                        d[1] === u &&
                        d[2] === l &&
                        (!s || d[3] === s)
                        ? (d[4](), !1)
                        : !0;
                });
            });
        }
        function t(c, r, s) {
            var a,
                u = !0;
            return (
                typeof CustomEvent == "function"
                    ? (a = new CustomEvent(r, { bubbles: u, detail: s }))
                    : ((a = document.createEvent("CustomEvent")),
                      a.initCustomEvent(r, u, !1, s)),
                c.dispatchEvent(a),
                a
            );
        }
        function f(c, r, s) {
            T(c, function (a) {
                a &&
                    T(r, function (u) {
                        u.split(" ").forEach(function (l) {
                            var d = l.split(".");
                            s(a, d[0], d[1]);
                        });
                    });
            });
        }
        function o() {
            n.forEach(function (c) {
                c[4]();
            }),
                b(n);
        }
        return { bind: e, unbind: i, dispatch: t, destroy: o };
    }
    var L = "destroy";
    function $(n) {
        var e = n ? n.event.bus : document.createDocumentFragment(),
            i = g();
        function t(o, c) {
            i.bind(e, O(o).join(" "), function (r) {
                c.apply(c, _(r.detail) ? r.detail : []);
            });
        }
        function f(o) {
            i.dispatch(e, o, y(arguments, 1));
        }
        return (
            n && n.event.on(L, i.destroy),
            C(i, { bus: e, on: t, off: E(i.unbind, e), emit: f })
        );
    }
    function K(n, e, i) {
        return Array.prototype.slice.call(n, e, i);
    }
    function h(n) {
        return n.bind.apply(n, [null].concat(K(arguments, 1)));
    }
    function I(n, e) {
        return typeof e === n;
    }
    h(I, "function"), h(I, "string");
    var R = h(I, "undefined"),
        x = Object.keys;
    function S(n, e, i) {
        if (n) {
            var t = x(n);
            t = i ? t.reverse() : t;
            for (var f = 0; f < t.length; f++) {
                var o = t[f];
                if (o !== "__proto__" && e(n[o], o) === !1) break;
            }
        }
        return n;
    }
    var D = "intersection",
        M = "intersection:in",
        U = "intersection:out";
    function B(n) {
        var e = n.Components;
        return {
            keyboard: {
                enable: function () {
                    e.Keyboard.disable(!1);
                },
                disable: function () {
                    e.Keyboard.disable(!0);
                },
            },
            autoplay: {
                enable: function () {
                    n.options.autoplay && e.Autoplay.play();
                },
                disable: function () {
                    e.Autoplay.pause();
                },
            },
            autoScroll: {
                enable: function () {
                    var t = e.AutoScroll;
                    t && t.play();
                },
                disable: function () {
                    var t = e.AutoScroll;
                    t && t.pause();
                },
            },
            video: {
                enable: function () {
                    var t = e.Video;
                    t && t.play();
                },
                disable: function () {
                    var t = e.Video;
                    t && t.pause();
                },
            },
        };
    }
    function F(n, e, i) {
        var t = $(n),
            f = t.emit,
            o = i.intersection || {},
            c = B(n),
            r;
        function s() {
            window.IntersectionObserver &&
                ((r = new IntersectionObserver(u, {
                    root: o.root,
                    rootMargin: o.rootMargin,
                    threshold: o.threshold,
                })),
                r.observe(n.root));
        }
        function a() {
            r && (r.disconnect(), (r = null));
        }
        function u(v) {
            var p = v[0];
            p && (p.isIntersecting ? d(p) : m(p), f(D, p));
        }
        function l(v) {
            S(v, function (p, H) {
                if (!R(p)) {
                    var A = c[H];
                    p ? A.enable() : A.disable();
                }
            });
        }
        function d(v) {
            l(o.inView || {}), f(M, v), o.once && a();
        }
        function m(v) {
            l(o.outView || {}), f(U, v);
        }
        return { mount: s, destroy: a };
    }
    typeof window < "u" &&
        ((window.splide = window.splide || {}),
        (window.splide.Extensions = window.splide.Extensions || {}),
        (window.splide.Extensions.Intersection = F));
});
